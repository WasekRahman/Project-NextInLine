/* ---------------------------------------------------
   Navigation bar 
----------------------------------------------------- */
$(document).ready(function () {

    $('#sidebarCollapse').on('click', function () {
        $('#sidebar').toggleClass('active');
    });

});
/* ---------------------------------------------------
   Sticky header
----------------------------------------------------- */ 

var dashboardInfo;

function initDropdown(initValues)
{
    var  buildingDropdown = document.getElementById('buildingName');
    for(var i=0;i<initValues.length;){
        var cname = document.createElement("BUTTON");
        cname.className = "dropdown-item";
        cname.innerHTML = initValues[i].name;
        cname.id = i;
        console.log(i + " " + cname.id);
        cname.onclick = function(){initDashboardInfo(counter++)};
        buildingDropdown.appendChild(cname);
        console.log(initValues[i].name);
    }
}
function initDashboardInfo(n)
{
    console.log(n);
    console.log("yet to develop");
}
$(document).ready(function(){
	$.ajax({url: "https://project-next-in-line.herokuapp.com/event/"}).done(function (events){
		$.ajax({url: "https://project-next-in-line.herokuapp.com/door/"}).done(function (doors){
			$.ajax({url: "https://project-next-in-line.herokuapp.com/dashboard/"}).done(function (data){
                dashboardInfo = data;
                console.log(dashboardInfo);
                initDropdown(data);
                initDashboardInfo(data[0]);
                /*
				for(var i=0;i<data.length;i++){
					var b = data[i];
                    var row="";
                    document.getElementById('companyName').innerHTML = b.name;
					row+="<div><h3>"+b.name+"</h3>";
					row+="<b>Capacity:</b> " + b.capacity + "<br />";
					row+="<b>Occupancy:</b> " + b.occupancy + "<br />";
					row+="<b>Status:</b> " + (b.capacity<b.occupancy ? "Over capacity" : (b.capacity-b.occupancy+" additional people may fit.")) + "<br />";
					var serviceRate = 100;
					row+="<b>Configured max throughput:</b> " + serviceRate + " customers/hour<br />";
					var entranceRate=0;
					for(var k=0;k<events.length;k++){
						for(var j=0;j<doors.length;j++){
							if(doors[j]._id===events[k].doorID && doors[j].entrance_exit){
								entranceRate++;
							}
						}
					}
					var rho = entranceRate / serviceRate;
					var l = (rho*rho)/(1-rho);
					var wq = l / entranceRate;
					var w = wq + 1/serviceRate;
					row+="<b>Expected Wait Time:</b> "+Math.round(w*60,0)+"mins<br />";
					row+="<hr />";
					row+="<div>";
					for(var j=0;j<doors.length;j++){
						if(doors[j].buildingID===b._id){
							row+="<b>"+doors[j].name+"</b>"+(doors[j].entrance_exit?" Entrance":" Exit");
							row+="<ul>";
							row+="<li>Sensor1:"+doors[j].sensor1comport+"</li>";
							row+="<li>Sensor2:"+doors[j].sensor2comport+"</li>";
							var eventTotal=0;
							for(var k=0;k<events.length;k++){
								if(events[k].doorID===doors[j]._id){
									eventTotal++;
								}
							}
							row+="<li>Events today:"+eventTotal+"</li>";
							row+="</ul>";
						}
					}
					row+="</div>";
					row+="</div>";
					$("#list").append(row);
                }
                */
			});
		});
	});
});

/* ---------------------------------------------------
   Doughnut chart
----------------------------------------------------- */

var ctxD = document.getElementById("doughnutChart").getContext('2d');
var myLineChart = new Chart(ctxD, {
type: 'doughnut',
data: {
datasets: [{
data: [, 50, 100, 40, 120],
backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C", "#949FB1", "#4D5360"],
hoverBackgroundColor: ["#FF5A5E", "#5AD3D1", "#FFC870", "#A8B3C5", "#616774"]
}],
labels: ["Capacity", "Occupancy"],
},
options: {
responsive: true
}
});
